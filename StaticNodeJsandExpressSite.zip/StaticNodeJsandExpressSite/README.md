Project 6  💥📚 
 This is the sixth of ten projects for the 🏡 Treehouse TechDegree Full Stack JavaScript.

 Static Node.js & Express Site

Exceed Expectations - I added an red hover over the learn button. I also set the test color of my brief intro to silver. As well as set font-style to Script.Inside Learn More I set the buttons blue :).

View project

1. Download this repo.
2. Navigate to the project directory in the command line/terminal.
3. Run 'npm install' (or view the required dependencies listed in the package.json file and install each manually).
4. Run 'npm start' to view the project in your browser at: localhost:3000